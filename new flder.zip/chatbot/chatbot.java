import edu.stanford.nlp.pipeline.*;
import java.util.Properties;
import java.util.Scanner;

public class Chatbot {

    private static StanfordCoreNLP pipeline;

    public static void main(String[] args) {
        // Set up the Stanford NLP pipeline
        Properties props = new Properties();
        props.setProperty("annotators", "tokenize,ssplit,pos,lemma,ner,parse");
        props.setProperty("outputFormat", "text");
        pipeline = new StanfordCoreNLP(props);

        // Start chat
        chat();
    }

    private static void chat() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Chatbot: Hello! I am your intelligent chatbot. How can I assist you today?");
        
        while (true) {
            System.out.print("You: ");
            String userInput = scanner.nextLine();

            if (userInput.equalsIgnoreCase("exit") || userInput.equalsIgnoreCase("quit")) {
                System.out.println("Chatbot: Goodbye!");
                break;
            }

            String response = generateResponse(userInput);
            System.out.println("Chatbot: " + response);
        }

        scanner.close();
    }

    private static String generateResponse(String input) {
        // Simple rule-based responses
        if (input.toLowerCase().contains("hello")) {
            return "Hi there! How can I help you?";
        } else if (input.toLowerCase().contains("how are you")) {
            return "I'm just a program, but thanks for asking!";
        } else if (input.toLowerCase().contains("your name")) {
            return "I am a chatbot created to assist you.";
        } else {
            return "I'm not sure how to respond to that.";
        }
    }
}